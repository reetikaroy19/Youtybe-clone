export const API_KEY='AIzaSyDY1VwoBjL8q3CfQrU-XG4oLhG7ps3vh0E';

// for views in videos M=million, k=thousund//
export const value_converter = (value) => {
    if(value>=1000000)
    {
        return Math.floor(value/1000000)+"M";
    }
    else if(value>=1000)
    {
        return Math.floor(value/1000)+"K";
    }
    else{
        return value;
    }
}